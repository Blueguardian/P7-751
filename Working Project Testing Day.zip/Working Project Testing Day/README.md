# P7-751
P7 Project - Tethered drone pose estimation
